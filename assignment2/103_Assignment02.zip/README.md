# SE319Assignment2
This is a small team project for Software Engineering 319 at Iowa State University. We will develop a small cart application with 3 views: a browse, cart, and confirmation view. 
